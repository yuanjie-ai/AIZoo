python -u train.py --num_classes 2 --save_dir ./checkpoint \
 --dataset_dir ../data --train_file train.json --dev_file dev.json --test_files test.json \
--model_name "ernie-3.0-xbase-zh" \
--max_seq_length 512 \
--batch_size 64


python -u find_dirty_data.py --num_classes 2  --init_from_ckpt ./checkpoint/model_state.pdparams \
--dataset_dir ./data --train_file train.json --rest_path ./data/dev.json --dirty_path ./data/dirty_train.tsv --dirty_num 500
--model_name "ernie-3.0-xbase-zh" \
--max_seq_length 512 \
--batch_size 64